# Uncle Sam Animated Poster

A Pen created on CodePen.io. Original URL: [https://codepen.io/mephysto/pen/MpGNmQ](https://codepen.io/mephysto/pen/MpGNmQ).

He wants you for the U.S. army