# Animated Panda with Tone.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/dazulu/pen/Oapowz](https://codepen.io/dazulu/pen/Oapowz).

I usually spend too much time trying to come up with something cool for the Codepen Challenge and then run out of time. Finally I pushed myself to just get started and see where it goes.  Simple but fun somehow, haha :)

It was overall more a challenge in animating the panda than anything else. The sounds are made by a basic implementation of Tone.js.

Panda SVG is my own creation.